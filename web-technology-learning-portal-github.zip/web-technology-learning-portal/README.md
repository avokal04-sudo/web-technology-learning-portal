# Web Technology Learning Portal

A beginner-friendly, three-page website built with HTML and CSS. It demonstrates practical concepts from Internet Programming Chapters 1 and 2.

## Pages

| File | Content |
|---|---|
| `index.html` | Internet and WWW concepts, URLs, text formatting, lists, hyperlinks, forms, and a simple JavaScript event |
| `media.html` | Images, image hyperlinks, video, audio, and embedded pages using `iframe` |
| `tables.html` | HTML table structure, headings, data cells, `colspan`, `rowspan`, and combined examples |

## Project structure

```text
web-technology-learning-portal/
├── index.html
├── media.html
├── tables.html
├── README.md
└── .gitignore
```

## Run locally

1. Download or clone this repository.
2. Keep all three HTML files in the same directory.
3. Open `index.html` in a web browser.
4. Use the navigation menu to move between the three pages.

No build tools or package installation are required.

## Publish with GitHub Pages

1. Create a new GitHub repository.
2. Upload all files in this project to the repository's root directory.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and the `/ (root)` folder, then save.
6. After GitHub Pages finishes deploying, open the website URL shown in the Pages settings.

## Learning notes

- `colspan` merges cells horizontally across columns.
- `rowspan` merges cells vertically across rows.
- The navigation links use relative file paths, so the three HTML files must remain together.
- The sample form is for front-end demonstration only. It does not store or submit data to a backend.
- Some image, audio, video, and iframe resources are hosted externally and require an Internet connection. External websites may change their URLs or restrict embedding.

## Technologies

- HTML5
- CSS3
- Basic JavaScript

## Educational use

This project is intended for learning and practicing introductory web development concepts.
